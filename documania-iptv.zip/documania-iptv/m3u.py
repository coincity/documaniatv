# -*- coding: utf-8 -*-
"""Generación de listas M3U"""

import config


def build_m3u(entries: list[dict]) -> str:
    """
    Genera una lista M3U compatible con TiviMate, IPTV Smarters,
    VLC, OTT Navigator, etc.
    Incluye User-Agent y Referer mediante #EXTVLCOPT.
    """
    lines = ["#EXTM3U"]

    for e in entries:
        title = e.get("title", "Sin título").replace(",", " ").replace("\n", " ")
        logo = e.get("poster", "")
        group = e.get("group", "DocumaniaTV")
        stream = e.get("stream", "")

        if not stream:
            continue

        lines.append(
            f'#EXTINF:-1 tvg-logo="{logo}" group-title="{group}",{title}'
        )
        # Headers que la mayoría de reproductores IPTV respetan
        lines.append(f"#EXTVLCOPT:http-user-agent={config.USER_AGENT}")
        lines.append(f"#EXTVLCOPT:http-referrer={config.MAIN_URL}/")
        # Algunos reproductores también aceptan esta forma
        lines.append(f"#EXTVLCOPT:http-referer={config.MAIN_URL}/")
        lines.append(stream)

    return "\n".join(lines) + "\n"
