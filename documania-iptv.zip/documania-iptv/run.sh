#!/data/data/com.termux/files/usr/bin/bash
# Arranque rápido en Termux

cd "$(dirname "$0")"

# Activar wake-lock si está disponible
if command -v termux-wake-lock >/dev/null 2>&1; then
  termux-wake-lock
fi

python server.py
