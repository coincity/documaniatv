# -*- coding: utf-8 -*-
"""
Servidor HTTP local para servir la playlist M3U de DocumaniaTV.
Pensado para usarse en Termux y consumirse desde la TV (misma red WiFi).
"""

from __future__ import annotations

import json
import socket
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import config
from m3u import build_m3u
from scraper import collect_all, extract_video_url, search


class PlaylistState:
    """Caché en memoria + disco de la playlist generada."""

    def __init__(self) -> None:
        self.entries: list[dict] = []
        self.m3u: str = ""
        self.generated_at: float = 0.0
        self._load_cache()

    def _load_cache(self) -> None:
        path = Path(config.CACHE_FILE)
        if not path.exists():
            return
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            self.entries = data.get("entries", [])
            self.m3u = build_m3u(self.entries)
            self.generated_at = data.get("generated_at", 0.0)
            print(f"✓ Caché cargada ({len(self.entries)} entradas)")
        except Exception as exc:
            print(f"No se pudo cargar caché: {exc}")

    def _save_cache(self) -> None:
        try:
            Path(config.CACHE_FILE).write_text(
                json.dumps(
                    {
                        "generated_at": self.generated_at,
                        "entries": self.entries,
                    },
                    ensure_ascii=False,
                    indent=2,
                ),
                encoding="utf-8",
            )
        except Exception as exc:
            print(f"No se pudo guardar caché: {exc}")

    def generate(self, force: bool = False) -> None:
        if self.entries and not force:
            print("Usando playlist en caché. Usa /refresh para regenerar.")
            return
        print("Generando playlist completa...")
        self.entries = collect_all()
        self.m3u = build_m3u(self.entries)
        self.generated_at = time.time()
        self._save_cache()
        print(f"Playlist lista: {len(self.entries)} canales")

    def search_and_build(self, query: str) -> str:
        print(f"Búsqueda: {query}")
        results = search(query)
        final = []
        for i, item in enumerate(results, 1):
            print(f"  [{i}/{len(results)}] {item['title'][:50]}...")
            stream = extract_video_url(item["url"])
            if stream:
                item["stream"] = stream
                item["group"] = f"Búsqueda: {query}"
                final.append(item)
            time.sleep(config.REQUEST_DELAY)
        return build_m3u(final)


state = PlaylistState()


def get_local_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "IP-DE-TU-DISPOSITIVO"


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt: str, *args) -> None:
        print(f"[HTTP] {args[0]}")

    def _send(self, code: int, body: bytes, content_type: str = "text/plain; charset=utf-8") -> None:
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"
        qs = parse_qs(parsed.query)

        # Página de inicio (ayuda)
        if path == "/":
            ip = get_local_ip()
            html = f"""<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>DocumaniaTV IPTV</title>
  <style>
    body {{ font-family: system-ui, sans-serif; max-width: 720px; margin: 2rem auto; padding: 0 1rem; background: #111; color: #eee; }}
    a {{ color: #6af; }}
    code {{ background: #222; padding: 2px 6px; border-radius: 4px; }}
    .box {{ background: #1a1a1a; border: 1px solid #333; border-radius: 8px; padding: 1rem 1.2rem; margin: 1rem 0; }}
    h1 {{ color: #8cf; }}
  </style>
</head>
<body>
  <h1>DocumaniaTV → IPTV</h1>
  <div class="box">
    <p><strong>Playlist principal:</strong><br>
    <code>http://{ip}:{config.PORT}/playlist.m3u</code></p>
    <p>Cópiala en TiviMate, IPTV Smarters, VLC, OTT Navigator, etc.</p>
  </div>
  <div class="box">
    <p><strong>Endpoints útiles</strong></p>
    <ul>
      <li><a href="/playlist.m3u">/playlist.m3u</a> – Lista completa (novedades + top + series)</li>
      <li><a href="/refresh">/refresh</a> – Regenera la lista (tarda varios minutos)</li>
      <li><code>/search?q=texto</code> – Búsqueda bajo demanda (ej: <a href="/search?q=naturaleza">/search?q=naturaleza</a>)</li>
      <li><a href="/status">/status</a> – Estado del servidor</li>
    </ul>
  </div>
  <p style="opacity:.6;font-size:.9rem">Móvil y TV deben estar en la misma red WiFi.</p>
</body>
</html>"""
            self._send(200, html.encode("utf-8"), "text/html; charset=utf-8")
            return

        # Playlist principal
        if path in ("/playlist.m3u", "/documania.m3u", "/lista.m3u"):
            if not state.m3u:
                state.generate()
            data = state.m3u.encode("utf-8")
            self._send(200, data, "application/vnd.apple.mpegurl")
            return

        # Regenerar
        if path == "/refresh":
            state.generate(force=True)
            msg = f"Playlist regenerada: {len(state.entries)} entradas\n"
            self._send(200, msg.encode("utf-8"))
            return

        # Búsqueda
        if path == "/search":
            query = (qs.get("q") or qs.get("query") or [""])[0].strip()
            if not query:
                self._send(400, b"Falta parametro q. Ejemplo: /search?q=cosmos\n")
                return
            m3u = state.search_and_build(query)
            self._send(200, m3u.encode("utf-8"), "application/vnd.apple.mpegurl")
            return

        # Estado
        if path == "/status":
            age = int(time.time() - state.generated_at) if state.generated_at else -1
            info = {
                "entries": len(state.entries),
                "generated_at": state.generated_at,
                "age_seconds": age,
                "port": config.PORT,
            }
            self._send(200, json.dumps(info, indent=2).encode("utf-8"), "application/json")
            return

        self._send(404, b"Not found\n")


def main() -> None:
    ip = get_local_ip()
    print("=" * 56)
    print("  DocumaniaTV IPTV Server")
    print("=" * 56)
    print(f"  URL para la TV:")
    print(f"  http://{ip}:{config.PORT}/playlist.m3u")
    print()
    print(f"  Página de ayuda:  http://{ip}:{config.PORT}/")
    print(f"  Regenerar lista:  http://{ip}:{config.PORT}/refresh")
    print(f"  Búsqueda:         http://{ip}:{config.PORT}/search?q=texto")
    print("=" * 56)
    print("  Ctrl+C para detener")
    print()

    # Generar (o cargar caché) al arrancar
    state.generate(force=False)

    server = HTTPServer(("0.0.0.0", config.PORT), Handler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor detenido.")


if __name__ == "__main__":
    main()
