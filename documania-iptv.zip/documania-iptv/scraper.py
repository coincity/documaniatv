# -*- coding: utf-8 -*-
"""Scraper de DocumaniaTV"""

import re
import time
from typing import Optional
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

import config

session = requests.Session()
session.headers.update({"User-Agent": config.USER_AGENT})


def _get(url: str, **kwargs) -> requests.Response:
    kwargs.setdefault("timeout", config.TIMEOUT)
    return session.get(url, **kwargs)


def get_image(path: str) -> str:
    if not path:
        return ""
    return path if path.startswith("http") else urljoin(config.MAIN_URL, path)


def extract_video_url(page_url: str) -> Optional[str]:
    """Extrae la URL directa del vídeo usando la misma lógica del provider original."""
    try:
        r = _get(page_url)
        r.raise_for_status()
        html = r.text

        m = re.search(r'uniq_id:\s*"([^"]+)"', html)
        if not m:
            return None
        video_id = m.group(1)

        # 1. Visitar embed para obtener cookies
        embed_url = f"{config.MAIN_URL}/embed/{video_id}"
        _get(embed_url)
        cookies = "; ".join(f"{c.name}={c.value}" for c in session.cookies)

        # 2. Pedir JSON
        json_headers = {
            "Referer": embed_url,
            "X-Requested-With": "XMLHttpRequest",
            "Cookie": cookies,
            "User-Agent": config.USER_AGENT,
        }
        jr = _get(f"{config.MAIN_URL}/json/{video_id}", headers=json_headers)
        text = jr.text

        for pattern in (
            r'"src"\s*:\s*"([^"]+)"',
            r'file:\s*"([^"]+)"',
            r'https?://[^\s"\']+\.mp4[^\s"\']*',
        ):
            m = re.search(pattern, text)
            if m:
                url = m.group(1) if m.lastindex else m.group(0)
                return url.replace("\\/", "/")

        # Fallback: player.js
        player = _get(
            f"{config.MAIN_URL}/docuplayer/v1/{video_id}.js",
            headers={
                "Referer": embed_url,
                "User-Agent": config.USER_AGENT,
                "Cookie": cookies,
            },
        ).text

        for pattern in (
            r'"src"\s*:\s*"([^"]+)"',
            r'file:\s*"([^"]+)"',
            r'https?://[^\s"\']+\.mp4[^\s"\']*',
        ):
            m = re.search(pattern, player)
            if m:
                url = m.group(1) if m.lastindex else m.group(0)
                return url.replace("\\/", "/")

    except Exception as exc:
        print(f"  [error extract] {page_url}: {exc}")
    return None


def scrape_list(url: str, limit: int = 40) -> list[dict]:
    """Scrapea una lista de documentales (novedades / top)."""
    items: list[dict] = []
    try:
        r = _get(url)
        soup = BeautifulSoup(r.text, "lxml")

        for thumb in soup.select(".pm-video-thumb")[:limit]:
            a = thumb.select_one("a")
            if not a:
                continue
            href = a.get("href") or ""
            if not href:
                continue
            href = urljoin(config.MAIN_URL, href)
            title = (a.get("title") or a.get_text(strip=True) or "Sin título").strip()
            img = thumb.select_one("img")
            poster = ""
            if img:
                src = img.get("src") or img.get("data-src") or ""
                poster = get_image(src)
            items.append({"title": title, "url": href, "poster": poster})
    except Exception as exc:
        print(f"Error scrapeando lista {url}: {exc}")
    return items


def scrape_series_list(limit: int = 10) -> list[dict]:
    """Obtiene las series más destacadas."""
    items: list[dict] = []
    try:
        r = _get(f"{config.MAIN_URL}/top-series-documentales-1.html")
        soup = BeautifulSoup(r.text, "lxml")

        for a in soup.select("a[href*='/documentales/']"):
            if a.select_one(".pm-video-thumb") is None and not a.select_one("img"):
                continue
            href = a.get("href") or ""
            if not href or "video_" in href:
                continue
            href = urljoin(config.MAIN_URL, href)
            title = (
                a.select_one("h3")
                and a.select_one("h3").get_text(strip=True)
                or a.get("title", "").removeprefix("Serie documental ").strip()
                or a.get_text(strip=True)
            )
            if not title:
                continue
            img = a.select_one("img")
            poster = ""
            if img:
                src = img.get("src") or img.get("data-src") or ""
                poster = get_image(src)
            items.append({"title": title, "url": href, "poster": poster, "is_series": True})
            if len(items) >= limit:
                break
    except Exception as exc:
        print(f"Error scrapeando series: {exc}")
    return items


def scrape_series_episodes(series_url: str, limit: int = 20) -> list[dict]:
    """Extrae los episodios de una serie."""
    episodes: list[dict] = []
    seen: set[str] = set()
    try:
        r = _get(series_url)
        soup = BeautifulSoup(r.text, "lxml")
        series_title = (
            soup.select_one("h1")
            and soup.select_one("h1").get_text(strip=True)
            or "Serie"
        )

        for a in soup.select("h3 a[href*='video_']"):
            href = a.get("href") or ""
            if not href:
                continue
            href = urljoin(config.MAIN_URL, href)
            if href in seen:
                continue
            seen.add(href)
            ep_title = a.get_text(strip=True) or f"Episodio {len(episodes) + 1}"
            full_title = f"{series_title} – {ep_title}"
            episodes.append(
                {
                    "title": full_title,
                    "url": href,
                    "poster": "",
                    "group": f"Serie: {series_title}",
                }
            )
            if len(episodes) >= limit:
                break
    except Exception as exc:
        print(f"Error episodios {series_url}: {exc}")
    return episodes


def search(query: str, limit: int = 25) -> list[dict]:
    """Búsqueda en el sitio."""
    items: list[dict] = []
    try:
        r = session.post(
            f"{config.MAIN_URL}/ajax_search.php",
            data={"queryString": query},
            headers={
                "User-Agent": config.USER_AGENT,
                "X-Requested-With": "XMLHttpRequest",
            },
            timeout=config.TIMEOUT,
        )
        soup = BeautifulSoup(r.text, "lxml")
        for li in soup.select("li"):
            a = li.select_one("a")
            if not a:
                continue
            href = a.get("href") or ""
            if not href or "video_" not in href:
                continue
            href = urljoin(config.MAIN_URL, href)
            title = a.get_text(strip=True)
            video_id = li.get("data-video-id") or href.split("video_")[-1].split(".")[0]
            poster = f"{config.MAIN_URL}/uploads/thumbs/{video_id}-1.webp"
            items.append({"title": title, "url": href, "poster": poster})
            if len(items) >= limit:
                break
    except Exception as exc:
        print(f"Error búsqueda '{query}': {exc}")
    return items


def collect_all() -> list[dict]:
    """Recoge novedades + top + series y extrae los streams."""
    all_items: list[dict] = []

    print("→ Scrapeando Novedades...")
    for it in scrape_list(
        f"{config.MAIN_URL}/documentales-nuevos.html", config.MAX_NOVEDADES
    ):
        it["group"] = "Novedades"
        all_items.append(it)

    print("→ Scrapeando Más Vistos...")
    for it in scrape_list(
        f"{config.MAIN_URL}/top-documentales.html", config.MAX_TOP
    ):
        it["group"] = "Más Vistos"
        all_items.append(it)

    print("→ Scrapeando Series...")
    series_list = scrape_series_list(config.MAX_SERIES)
    for s in series_list:
        print(f"  · Serie: {s['title']}")
        episodes = scrape_series_episodes(s["url"], config.MAX_EPISODES_PER_SERIES)
        all_items.extend(episodes)
        time.sleep(config.REQUEST_DELAY)

    # Deduplicar por URL
    seen: set[str] = set()
    unique: list[dict] = []
    for it in all_items:
        if it["url"] not in seen:
            seen.add(it["url"])
            unique.append(it)

    print(f"→ Extrayendo streams de {len(unique)} elementos (puede tardar)...")
    final: list[dict] = []
    for i, item in enumerate(unique, 1):
        short = item["title"][:55]
        print(f"  [{i}/{len(unique)}] {short}...")
        stream = extract_video_url(item["url"])
        if stream:
            item["stream"] = stream
            final.append(item)
        time.sleep(config.REQUEST_DELAY)

    print(f"✓ {len(final)} streams válidos de {len(unique)} intentos")
    return final
