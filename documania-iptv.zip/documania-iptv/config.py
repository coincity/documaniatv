# -*- coding: utf-8 -*-
"""Configuración de DocumaniaTV IPTV Server"""

# Puerto del servidor HTTP (accesible en la red local)
PORT = 8080

# URL base del sitio
MAIN_URL = "https://www.documaniatv.com"

# User-Agent realista
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/120.0.0.0 Safari/537.36"
)

# Límites de scraping (ajusta según tu red y paciencia)
MAX_NOVEDADES = 30
MAX_TOP = 25
MAX_SERIES = 8          # Cuántas series incluir
MAX_EPISODES_PER_SERIES = 20

# Tiempo de espera entre peticiones (segundos) para no saturar el servidor
REQUEST_DELAY = 0.7

# Caché de la playlist en memoria (se regenera con /refresh)
# También se guarda en disco para reinicios rápidos
CACHE_FILE = "playlist_cache.json"

# Timeout de peticiones HTTP
TIMEOUT = 15
