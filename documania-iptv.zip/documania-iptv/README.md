# DocumaniaTV → IPTV (M3U)

Servidor local en Python que scrapea [DocumaniaTV](https://www.documaniatv.com), genera una lista **M3U** con los streams y la sirve en tu red WiFi para ver documentales en la TV (TiviMate, IPTV Smarters, VLC, OTT Navigator, etc.).

Pensado para ejecutarse en **Termux** (Android).

---

## Características

- Novedades + Más vistos + Series documentales
- Extracción de streams con headers (User-Agent + Referer)
- Caché en disco (reinicios rápidos)
- Endpoint de búsqueda bajo demanda
- Página de ayuda en el navegador
- Compatible con la mayoría de reproductores IPTV

---

## Requisitos (Termux)

```bash
pkg update && pkg upgrade
pkg install python git
pip install -r requirements.txt
```

---

## Instalación rápida

```bash
# Clonar (sustituye por tu repo cuando lo subas a GitHub)
git clone https://github.com/TU_USUARIO/documania-iptv.git
cd documania-iptv

pip install -r requirements.txt
python server.py
```

Al arrancar verás algo como:

```
http://192.168.1.XX:8080/playlist.m3u
```

Copia esa URL en tu reproductor IPTV de la TV (misma red WiFi).

---

## Uso en la TV

1. Abre **TiviMate**, **IPTV Smarters**, **OTT Navigator**, **VLC**, etc.
2. Añadir lista → URL
3. Pega: `http://IP-DE-TU-MOVIL:8080/playlist.m3u`
4. Asegúrate de que el móvil y la TV estén en la **misma red WiFi**.

---

## Endpoints

| Ruta | Descripción |
|------|-------------|
| `/` | Página de ayuda |
| `/playlist.m3u` | Lista completa (novedades + top + series) |
| `/refresh` | Regenera la lista (tarda varios minutos) |
| `/search?q=texto` | Búsqueda bajo demanda (ej: `/search?q=cosmos`) |
| `/status` | Estado JSON del servidor |

---

## Configuración

Edita `config.py` para cambiar:

- `PORT` – puerto del servidor (por defecto 8080)
- `MAX_NOVEDADES`, `MAX_TOP`, `MAX_SERIES`, `MAX_EPISODES_PER_SERIES`
- `REQUEST_DELAY` – pausa entre peticiones (sé educado con el sitio)

---

## Consejos Termux

```bash
# Evitar que Android mate el proceso al apagar pantalla
termux-wake-lock

# Ejecutar en segundo plano (opcional)
nohup python server.py > server.log 2>&1 &

# Ver log
tail -f server.log
```

Deja el móvil cargando si vas a usarlo mucho rato.

---

## Estructura del proyecto

```
documania-iptv/
├── config.py          # Ajustes
├── scraper.py         # Scraping de DocumaniaTV
├── m3u.py             # Generación de la lista M3U
├── server.py          # Servidor HTTP (punto de entrada)
├── requirements.txt
├── README.md
└── .gitignore
```

---

## Notas

- La primera generación de la playlist puede tardar varios minutos (extrae los streams uno a uno).
- Después se usa la caché hasta que llames a `/refresh`.
- Solo accesible en tu red local. No expongas el puerto a Internet.
- El sitio puede cambiar su estructura HTML/JS; si deja de funcionar habrá que actualizar los selectores en `scraper.py`.

---

## Licencia

Uso personal / educativo. Respeta los términos del sitio original.
